
print("Welcome to random username generator")
cname = input("What is your fav charachter/hero?\n")
pname= input("Your fav pet name\n")
print("Your username  is "+ cname +"_"+ pname )
